import { useState } from 'react';

function App() {
  const [user, setUser] = useState({ username: '', password: '' });

  const handleLogin = () => {
    alert(`Logging in as ${user.username}`);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <nav className="bg-white shadow p-4 flex justify-between items-center">
        <div className="text-xl font-bold text-red-600">RobloxMock</div>
        <div className="space-x-4">
          <button className="px-4 py-2 border rounded">Login</button>
          <button className="px-4 py-2 bg-red-600 text-white rounded">Sign Up</button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="p-6 text-center">
        <h1 className="text-3xl font-bold mb-2">Welcome to RobloxMock</h1>
        <p className="text-gray-600">Experience games made by the community!</p>
      </div>

      {/* Login Form */}
      <div className="max-w-md mx-auto bg-white shadow-md rounded p-6 mt-6">
        <h2 className="text-2xl font-semibold mb-4">Login</h2>
        <div className="space-y-4">
          <input
            className="w-full p-2 border rounded"
            placeholder="Username or Email"
            value={user.username}
            onChange={(e) => setUser({ ...user, username: e.target.value })}
          />
          <input
            type="password"
            className="w-full p-2 border rounded"
            placeholder="Password"
            value={user.password}
            onChange={(e) => setUser({ ...user, password: e.target.value })}
          />
          <button className="w-full bg-red-600 text-white py-2 rounded" onClick={handleLogin}>
            Login
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;